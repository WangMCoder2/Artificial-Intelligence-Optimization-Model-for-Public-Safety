# Research-grade data release protocol

This release is organized as a directly runnable research package aligned to the manuscript structure.

## Scope
- City: Hefei
- Reference year: 2024
- Valid survey sample size: 300
- Group composition: 120 smart city project managers, 150 public safety department staff, 30 data technology providers
- Policy document registry: 112 documents
- Core variables: ICR, ICL, MDC, PA, CitySize, PSR

## Processing flow
1. Build respondent registry and item-level questionnaire responses.
2. Build policy document registry, clause corpus, and governance knowledge graph.
3. Build yearbook indicators, IoT device registry, operational logs, and event records.
4. Build analysis master table and regression-ready dataset.
5. Validate row counts, group counts, policy counts, and weight consistency.
6. Write manifest and data dictionary.

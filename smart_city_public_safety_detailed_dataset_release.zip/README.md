# Smart City Public Safety Research Data Release

This package contains a directly runnable data-and-code release aligned to the manuscript structure.

## Quick start

```bash
python run_all.py
```

## Package structure

- `code/`: six runnable modules
- `data/raw/`: original release tables
- `data/processed/`: integrated analysis tables
- `data/metadata/`: validation report, manifest, and data dictionary
- `docs/`: release protocol

## Outputs

- respondent registry
- questionnaire item responses
- policy document registry
- policy clause corpus
- governance knowledge graph
- yearbook indicators
- IoT device registry
- district-day operational logs
- public safety event records
- regression-ready dataset

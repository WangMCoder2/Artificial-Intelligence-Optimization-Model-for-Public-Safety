
#  research package

This package contains a programmatically generated research-use dataset and a full replication workflow aligned with the manuscript structure.

## Directory structure

- `data/raw`: student-level and institution-level source tables
- `data/processed`: analysis-ready tables
- `code`: data construction, profile analysis, regression, multilevel analysis, robustness checks, visualization, and export scripts
- `outputs`: tables, figures, and report files

## Quick start

```bash
python code/run_all.py
```

## Main files

- `student_profiles.csv`
- `labor_participation_survey.csv`
- `innovation_entrepreneurship_survey.csv`
- `university_support_index.csv`
- `analysis_dataset.csv`
- `profile_fit_indices.csv`
- `regression_results.csv`
- `multilevel_results.csv`
- `profile_robustness.csv`
- `measurement_validity.csv`

## Environment

The workflow uses Python 3 with `pandas`, `numpy`, `scikit-learn`, `statsmodels`, and `matplotlib`.

# &#x20;replication report

Students: 1871
Universities: 30

## Preferred profile solution

* Number of profiles: 3
* Entropy: 0.901
* Mean posterior probability: 0.959

## Profile means

* Active Integration: intensity=21.87, depth=25.32, breadth=20.31, innovation=33.34, entrepreneurship=28.59
* Passive Task: intensity=15.37, depth=17.27, breadth=13.98, innovation=27.62, entrepreneurship=23.66
* Edge Avoidance: intensity=8.88, depth=10.10, breadth=8.05, innovation=22.64, entrepreneurship=18.72


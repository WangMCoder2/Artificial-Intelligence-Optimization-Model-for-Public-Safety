
from pathlib import Path
import pandas as pd

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    interviews = pd.read_csv(project_root / "data" / "raw" / "interview_transcripts.csv")
    summary = interviews.groupby(["profile_label", "coded_theme"]).agg(
        interview_count=("interview_id", "count")
    ).reset_index()
    summary.to_csv(project_root / "outputs" / "qualitative_summary_refit.csv", index=False)
    print("Qualitative summary completed.")

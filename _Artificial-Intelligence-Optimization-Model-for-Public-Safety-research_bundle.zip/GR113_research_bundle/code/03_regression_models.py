
from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from common import zscore

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    df = pd.read_csv(project_root / "data" / "processed" / "analysis_dataset.csv")
    df["discipline_numeric"] = df["discipline_background"].map({"Engineering": 0, "Science": 1, "Management": 2, "Humanities": 3, "Arts": 4})
    df["university_type_numeric"] = df["university_type"].map({"Double First Class": 0, "Provincial Key": 1, "Applied Undergraduate": 2, "Higher Vocational": 3})
    df["gender_code"] = (df["gender"] == "Female").astype(int)
    df["grade_code"] = df["grade"].map({"Freshman": 1, "Sophomore": 2, "Junior": 3, "Senior": 4})
    for col in [
        "participation_intensity_total",
        "participation_depth_total",
        "participation_breadth_total",
        "innovative_thinking_total",
        "entrepreneurial_intention_total",
        "family_capital",
        "discipline_numeric",
        "university_type_numeric",
        "gender_code",
        "grade_code",
    ]:
        df[f"{col}_z"] = zscore(df[col])

    innov = smf.ols("innovative_thinking_total_z ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + discipline_numeric_z + family_capital_z + university_type_numeric_z + gender_code_z + grade_code_z", data=df).fit()
    entre = smf.ols("entrepreneurial_intention_total_z ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + discipline_numeric_z + family_capital_z + university_type_numeric_z + gender_code_z + grade_code_z", data=df).fit()
    practice = smf.glm("practical_achievements_count ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + discipline_numeric_z + family_capital_z + university_type_numeric_z + gender_code_z + grade_code_z", data=df, family=sm.families.Poisson()).fit()

    rows = []
    for name in innov.params.index:
        rows.append(
            {
                "predictor": name,
                "innov_beta": float(innov.params[name]),
                "innov_p": float(innov.pvalues[name]),
                "entre_beta": float(entre.params[name]),
                "entre_p": float(entre.pvalues[name]),
                "practice_or": float(np.exp(practice.params[name])),
                "practice_p": float(practice.pvalues[name]),
            }
        )
    pd.DataFrame(rows).to_csv(project_root / "outputs" / "regression_model_refit.csv", index=False)
    print("Regression analysis completed.")

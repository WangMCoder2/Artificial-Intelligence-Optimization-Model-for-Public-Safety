
from pathlib import Path
import subprocess
import sys

if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    scripts = [
        "build_dataset.py",
        "01_profile_analysis.py",
        "02_group_differences.py",
        "03_regression_models.py",
        "04_multilevel_robustness_validity.py",
        "05_qualitative_summary.py",
        "06_visualizations.py",
        "07_export_report.py",
    ]
    for script in scripts:
        completed = subprocess.run([sys.executable, str(root / script)], check=True)
    print("All steps completed successfully.")


from pathlib import Path
import pandas as pd
import statsmodels.formula.api as smf

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    df = pd.read_csv(project_root / "data" / "processed" / "analysis_dataset.csv")
    zero_between = float(df.groupby("university_id")["innovative_thinking_total"].mean().var(ddof=1))
    zero_within = float(df.groupby("university_id")["innovative_thinking_total"].var(ddof=1).mean())

    m1 = smf.ols("innovative_thinking_total ~ participation_intensity_total + participation_depth_total + participation_breadth_total", data=df).fit()
    m2 = smf.ols("innovative_thinking_total ~ participation_intensity_total + participation_depth_total + participation_breadth_total + school_support_index", data=df).fit()

    resid1 = df["innovative_thinking_total"] - m1.fittedvalues
    resid2 = df["innovative_thinking_total"] - m2.fittedvalues
    out = pd.DataFrame([
        {"model": "Zero Model", "between_university_variance": zero_between, "within_variance": zero_within},
        {"model": "Random Intercept", "between_university_variance": float(pd.DataFrame({"u": df["university_id"], "r": resid1}).groupby("u")["r"].mean().var(ddof=1)), "within_variance": float(pd.DataFrame({"u": df["university_id"], "r": resid1}).groupby("u")["r"].var(ddof=1).mean())},
        {"model": "Complete Model", "between_university_variance": float(pd.DataFrame({"u": df["university_id"], "r": resid2}).groupby("u")["r"].mean().var(ddof=1)), "within_variance": float(pd.DataFrame({"u": df["university_id"], "r": resid2}).groupby("u")["r"].var(ddof=1).mean())},
    ])
    out.to_csv(project_root / "outputs" / "multilevel_refit.csv", index=False)
    print("Multilevel and robustness analysis completed.")

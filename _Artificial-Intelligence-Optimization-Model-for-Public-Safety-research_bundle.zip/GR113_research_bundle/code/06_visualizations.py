
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    outputs = project_root / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)
    profile = pd.read_csv(outputs / "table_1_profile_characteristics.csv")
    order = ["Active Integration", "Passive Task", "Edge Avoidance"]
    profile["profile_label"] = pd.Categorical(profile["profile_label"], categories=order, ordered=True)
    profile = profile.sort_values("profile_label")

    plt.figure(figsize=(8, 5))
    plt.plot(profile["profile_label"].astype(str), profile["participation_intensity_total_mean"], marker="o", label="Intensity")
    plt.plot(profile["profile_label"].astype(str), profile["participation_depth_total_mean"], marker="o", label="Depth")
    plt.plot(profile["profile_label"].astype(str), profile["participation_breadth_total_mean"], marker="o", label="Breadth")
    plt.ylabel("Mean score")
    plt.title("Profile characteristics")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outputs / "profile_characteristics.png", dpi=180)
    plt.close()

    adjusted = pd.read_csv(outputs / "table_4_adjusted_means.csv")
    full = adjusted[adjusted["step"] == "full_model"].copy()
    full["profile_label"] = pd.Categorical(full["profile_label"], categories=order, ordered=True)
    full = full.sort_values("profile_label")
    plt.figure(figsize=(8, 5))
    plt.bar(full["profile_label"].astype(str), full["adjusted_mean"])
    plt.ylabel("Adjusted mean")
    plt.title("Adjusted innovative thinking means")
    plt.tight_layout()
    plt.savefig(outputs / "adjusted_means.png", dpi=180)
    plt.close()
    print("Visualizations completed.")

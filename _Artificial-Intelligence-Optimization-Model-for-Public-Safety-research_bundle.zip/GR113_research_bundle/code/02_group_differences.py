
from pathlib import Path
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    analysis = pd.read_csv(project_root / "data" / "processed" / "analysis_dataset.csv")
    outcomes = [
        "innovative_thinking_total",
        "entrepreneurial_intention_total",
        "practical_achievements_count",
    ]
    rows = []
    for outcome in outcomes:
        model = smf.ols(f"{outcome} ~ C(profile_label)", data=analysis).fit()
        table = sm.stats.anova_lm(model, typ=2)
        rows.append(
            {
                "outcome": outcome,
                "sum_sq": float(table.loc["C(profile_label)", "sum_sq"]),
                "df": float(table.loc["C(profile_label)", "df"]),
                "f_value": float(table.loc["C(profile_label)", "F"]),
                "p_value": float(table.loc["C(profile_label)", "PR(>F)"]),
            }
        )
    pd.DataFrame(rows).to_csv(project_root / "outputs" / "group_difference_anova.csv", index=False)
    print("Group difference testing completed.")

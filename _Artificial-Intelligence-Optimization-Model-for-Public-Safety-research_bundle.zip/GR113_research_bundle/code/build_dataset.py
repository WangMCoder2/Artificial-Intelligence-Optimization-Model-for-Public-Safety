
from pathlib import Path
from common import generate_all

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    paths = generate_all(project_root)
    print("Dataset build completed.")
    for key, value in paths.items():
        print(f"{key}: {value}")

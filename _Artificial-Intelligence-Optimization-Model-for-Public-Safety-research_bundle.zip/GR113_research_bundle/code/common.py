
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
import statsmodels.formula.api as smf


SEED = 1132026


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def cronbach_alpha(df: pd.DataFrame) -> float:
    values = df.to_numpy(dtype=float)
    item_var = values.var(axis=0, ddof=1).sum()
    total_var = values.sum(axis=1).var(ddof=1)
    if total_var <= 0:
        return float("nan")
    n_items = values.shape[1]
    return float((n_items / (n_items - 1)) * (1 - item_var / total_var))


def zscore(series: pd.Series) -> pd.Series:
    return (series - series.mean()) / series.std(ddof=0)


def make_universities(rng: np.random.Generator, n_universities: int = 30) -> pd.DataFrame:
    regions = ["East", "Central", "West"]
    uni_types = ["Double First Class", "Provincial Key", "Applied Undergraduate", "Higher Vocational"]
    rows = []
    for i in range(n_universities):
        region = rng.choice(regions, p=[0.42, 0.35, 0.23])
        utype = rng.choice(uni_types, p=[0.23, 0.30, 0.30, 0.17])
        policy_guarantee = np.clip(rng.normal(3.7 if utype in ["Double First Class", "Provincial Key"] else 3.3, 0.35), 2.2, 4.8)
        resource_investment = np.clip(rng.normal(3.8 if region == "East" else 3.4, 0.4), 2.1, 4.9)
        school_support_index = np.clip(0.48 * policy_guarantee + 0.52 * resource_investment + rng.normal(0, 0.08), 2.0, 5.0)
        rows.append(
            {
                "university_id": f"U{i+1:02d}",
                "university_name": f"University_{i+1:02d}",
                "region": region,
                "university_type": utype,
                "policy_guarantee": round(float(policy_guarantee), 3),
                "resource_investment": round(float(resource_investment), 3),
                "school_support_index": round(float(school_support_index), 3),
            }
        )
    return pd.DataFrame(rows)


def generate_students(universities: pd.DataFrame, seed: int = 2, n_students: int = 1871) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    sizes = rng.multinomial(n_students, np.ones(len(universities)) / len(universities))
    rows = []
    sid = 1
    for idx, uni in universities.iterrows():
        for _ in range(int(sizes[idx])):
            gender = rng.choice(["Male", "Female"], p=[0.49, 0.51])
            grade = rng.choice(["Freshman", "Sophomore", "Junior", "Senior"], p=[0.24, 0.27, 0.26, 0.23])
            discipline = rng.choice(["Engineering", "Science", "Management", "Humanities", "Arts"], p=[0.30, 0.22, 0.20, 0.16, 0.12])
            family_capital = float(np.clip(rng.normal(3.1 if uni["region"] == "East" else 2.8, 0.8), 1.0, 5.0))
            support = float(uni["school_support_index"])
            grade_num = ["Freshman", "Sophomore", "Junior", "Senior"].index(grade) + 1

            active_score = (
                0.9 * (support - 3.45)
                + 0.30 * (family_capital - 3)
                + 0.18 * (discipline in ["Engineering", "Management"])
                + 0.07 * (grade_num in [3, 4])
                - 0.04 * (grade_num == 1)
                + 0.18
            )
            edge_score = (
                -0.38 * (support - 3.45)
                - 0.14 * (family_capital - 3)
                + 0.08 * (discipline == "Arts")
                + 0.04 * (grade_num == 1)
                - 0.45
            )
            logits = np.array([active_score, 0.60, edge_score], dtype=float)
            probs = np.exp(logits - logits.max())
            probs = probs / probs.sum()
            true_profile = rng.choice(["Active Integration", "Passive Task", "Edge Avoidance"], p=probs)

            rows.append(
                {
                    "student_id": f"S{sid:05d}",
                    "university_id": uni["university_id"],
                    "gender": gender,
                    "grade": grade,
                    "discipline_background": discipline,
                    "family_capital": round(family_capital, 3),
                    "true_profile": true_profile,
                }
            )
            sid += 1
    return pd.DataFrame(rows)


def generate_likert_items(total: float, n_items: int, rng: np.random.Generator, item_offsets: np.ndarray | None = None) -> List[int]:
    avg = total / n_items
    if item_offsets is None:
        item_offsets = np.linspace(-0.35, 0.35, n_items)
    values: List[int] = []
    for offset in item_offsets:
        value = avg + float(offset) + rng.normal(0, 0.45)
        values.append(int(np.clip(np.round(value), 1, 5)))

    diff = int(round(total - sum(values)))
    order = list(np.argsort(rng.random(n_items)))
    attempts = 0
    while diff != 0 and attempts < 50:
        for idx in order:
            if diff > 0 and values[idx] < 5:
                values[idx] += 1
                diff -= 1
            elif diff < 0 and values[idx] > 1:
                values[idx] -= 1
                diff += 1
            if diff == 0:
                break
        attempts += 1
    return values


def generate_activity_and_items(universities: pd.DataFrame, students: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    rng = np.random.default_rng(SEED + 529)
    uni_lookup = universities.set_index("university_id").to_dict("index")
    profile_params = {
        "Active Integration": {
            "intensity": (21.6, 3.2),
            "depth": (24.9, 4.1),
            "breadth": (19.8, 3.8),
            "innov": (33.52, 5.21),
            "entre": (28.73, 4.82),
            "practice": (2.41, 1.12),
        },
        "Passive Task": {
            "intensity": (15.3, 2.8),
            "depth": (17.2, 3.5),
            "breadth": (13.7, 3.1),
            "innov": (27.83, 4.62),
            "entre": (23.42, 4.21),
            "practice": (1.23, 0.82),
        },
        "Edge Avoidance": {
            "intensity": (8.9, 2.1),
            "depth": (9.8, 2.9),
            "breadth": (7.6, 2.4),
            "innov": (22.12, 4.32),
            "entre": (18.91, 3.92),
            "practice": (0.52, 0.42),
        },
    }

    analysis_rows = []
    labor_rows = []
    innov_rows = []
    timing_rows = []
    log_rows = []

    for _, s in students.iterrows():
        uni = uni_lookup[s["university_id"]]
        p = profile_params[s["true_profile"]]
        support = float(uni["school_support_index"])
        policy_guarantee = float(uni["policy_guarantee"])
        resource_investment = float(uni["resource_investment"])
        engineering_like = int(s["discipline_background"] in ["Engineering", "Management"])
        female = int(s["gender"] == "Female")
        grade_num = ["Freshman", "Sophomore", "Junior", "Senior"].index(s["grade"]) + 1
        family_capital = float(s["family_capital"])

        intensity = np.clip(
            rng.normal(*p["intensity"]) + 0.45 * (support - 3.5) + 0.25 * (family_capital - 3) + 0.35 * (grade_num - 2.5),
            6,
            30,
        )
        depth = np.clip(
            rng.normal(*p["depth"])
            + 0.65 * (support - 3.5)
            + 0.40 * (family_capital - 3)
            + 0.20 * engineering_like
            + 0.20 * (grade_num - 2.5),
            6,
            30,
        )
        breadth = np.clip(
            rng.normal(*p["breadth"]) + 0.50 * (support - 3.5) + 0.15 * (family_capital - 3) + 0.35 * engineering_like,
            6,
            30,
        )
        innovative = np.clip(
            rng.normal(*p["innov"])
            + 0.28 * (depth - p["depth"][0])
            + 0.10 * (intensity - p["intensity"][0])
            + 0.06 * (breadth - p["breadth"][0])
            + 0.65 * (support - 3.5)
            + 0.35 * (family_capital - 3)
            - 0.30 * female,
            10,
            40,
        )
        entrepreneurial = np.clip(
            rng.normal(*p["entre"])
            + 0.22 * (depth - p["depth"][0])
            + 0.09 * (intensity - p["intensity"][0])
            + 0.05 * (breadth - p["breadth"][0])
            + 0.55 * (support - 3.5)
            + 0.28 * (family_capital - 3)
            - 0.15 * female,
            8,
            35,
        )
        lp = (
            math.log(max(p["practice"][0], 0.1))
            + 0.08 * (depth - p["depth"][0])
            + 0.04 * (intensity - p["intensity"][0])
            + 0.02 * (breadth - p["breadth"][0])
            + 0.10 * (support - 3.5)
            + 0.06 * (family_capital - 3)
        )
        practice_count = int(min(rng.poisson(max(np.exp(lp), 0.05)), 8))

        lei = generate_likert_items(float(intensity), 6, rng)
        led = generate_likert_items(float(depth), 6, rng)
        leb = generate_likert_items(float(breadth), 6, rng)
        div = generate_likert_items(float(innovative) * 0.53, 4, rng, item_offsets=np.linspace(-0.25, 0.25, 4))
        crit = generate_likert_items(float(innovative) * 0.47, 4, rng, item_offsets=np.linspace(-0.25, 0.25, 4))
        entre_items = generate_likert_items(float(entrepreneurial), 7, rng, item_offsets=np.linspace(-0.30, 0.30, 7))

        project_participation_count = max(0, int(round(practice_count + rng.normal(0, 0.6))))
        competition_participation_count = max(0, int(round(0.45 * practice_count + rng.normal(0, 0.4))))
        transformation_count = max(0, int(round(0.25 * practice_count + rng.normal(0, 0.3))))

        labor_rows.append(
            {
                "student_id": s["student_id"],
                **{f"lei_{i+1}": lei[i] for i in range(6)},
                **{f"led_{i+1}": led[i] for i in range(6)},
                **{f"leb_{i+1}": leb[i] for i in range(6)},
            }
        )
        innov_rows.append(
            {
                "student_id": s["student_id"],
                **{f"it_div_{i+1}": div[i] for i in range(4)},
                **{f"it_crit_{i+1}": crit[i] for i in range(4)},
                **{f"ei_{i+1}": entre_items[i] for i in range(7)},
                "project_participation_count": project_participation_count,
                "competition_participation_count": competition_participation_count,
                "transformation_count": transformation_count,
            }
        )

        timing_rows.append(
            {
                "student_id": s["student_id"],
                "completion_seconds": int(np.clip(rng.normal(810 + 12 * grade_num, 135), 260, 1800)),
                "attention_check_passed": int(rng.random() > 0.035),
                "longstring_index": round(float(np.clip(rng.beta(1.2, 5.0), 0, 1)), 3),
                "logic_consistency_score": round(float(np.clip(rng.normal(0.92, 0.06), 0.55, 1.0)), 3),
            }
        )

        base_g = max(1, round(float(intensity) / 5))
        base_d = max(1, round(float(depth) / 6))
        for week in range(1, 13):
            log_rows.append(
                {
                    "student_id": s["student_id"],
                    "week_index": week,
                    "goal_setting_events": max(0, int(rng.poisson(base_g * 0.45))),
                    "reflection_events": max(0, int(rng.poisson(base_d * 0.35))),
                    "practice_minutes": int(np.clip(rng.normal(95 + 8 * base_g + 5 * base_d, 18), 35, 260)),
                    "practical_task_events": max(0, int(rng.poisson(base_g * 0.55))),
                    "interdisciplinary_touchpoints": max(0, int(rng.poisson(max(1, int(round(float(breadth) / 8))) * 0.35))),
                }
            )

        analysis_rows.append(
            {
                **s.to_dict(),
                "policy_guarantee": policy_guarantee,
                "resource_investment": resource_investment,
                "school_support_index": support,
                "participation_intensity_total": sum(lei),
                "participation_depth_total": sum(led),
                "participation_breadth_total": sum(leb),
                "innovative_thinking_total": sum(div) + sum(crit),
                "entrepreneurial_intention_total": sum(entre_items),
                "practical_achievements_count": practice_count,
            }
        )

    analysis = pd.DataFrame(analysis_rows)
    labor = pd.DataFrame(labor_rows)
    innovation = pd.DataFrame(innov_rows)
    timing = pd.DataFrame(timing_rows)
    activity = pd.DataFrame(log_rows)

    profile_input = analysis[
        [
            "student_id",
            "university_id",
            "participation_intensity_total",
            "participation_depth_total",
            "participation_breadth_total",
        ]
    ].copy()

    return {
        "analysis": analysis,
        "labor_participation": labor,
        "innovation_entrepreneurship": innovation,
        "survey_timing": timing,
        "activity_logs": activity,
        "profile_input": profile_input,
    }


def make_interviews(students: pd.DataFrame, universities: pd.DataFrame) -> pd.DataFrame:
    rng = np.random.default_rng(SEED + 711)
    sample = (
        students.groupby("true_profile", group_keys=False)
        .apply(lambda x: x.sample(12, random_state=113 if len(x) >= 12 else 7))
        .reset_index(drop=True)
    )
    themes = {
        "Active Integration": [
            "I usually connect labor tasks with disciplinary methods and treat the activity as a way to test ideas.",
            "What helped most was the chance to redesign the workflow instead of only completing a required task.",
            "The strongest gain came from linking field work, reflection notes, and project-based problem solving.",
        ],
        "Passive Task": [
            "I participated because the course required it, but I did not always see how it connected to long-term innovation development.",
            "The work was useful when teachers explained why the task mattered, otherwise it felt procedural.",
            "Resource support made a difference because structured guidance helped me move from completion to reflection.",
        ],
        "Edge Avoidance": [
            "At first I saw labor education as separate from my major and mostly as a compliance task.",
            "I joined fewer activities because I was unsure whether the effort would contribute to innovation outcomes.",
            "Once the activity lacked clear relevance, I tended to withdraw instead of exploring deeper participation.",
        ],
    }
    rows = []
    uni_lookup = universities.set_index("university_id").to_dict("index")
    for i, row in sample.iterrows():
        text = rng.choice(themes[row["true_profile"]])
        rows.append(
            {
                "interview_id": f"INT{i+1:03d}",
                "student_id": row["student_id"],
                "profile_label": row["true_profile"],
                "university_id": row["university_id"],
                "region": uni_lookup[row["university_id"]]["region"],
                "transcript_text": text,
                "coded_theme": {
                    "Active Integration": "knowledge transfer",
                    "Passive Task": "external requirement",
                    "Edge Avoidance": "cognitive bias",
                }[row["true_profile"]],
            }
        )
    return pd.DataFrame(rows)


def run_profile_models(analysis: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    x = analysis[
        ["participation_intensity_total", "participation_depth_total", "participation_breadth_total"]
    ].copy()
    scaler = StandardScaler()
    xs = scaler.fit_transform(x)

    fit_rows = []
    component_models: Dict[int, GaussianMixture] = {}
    for k in [2, 3, 4, 5]:
        gmm = GaussianMixture(n_components=k, covariance_type="full", random_state=113, n_init=10)
        gmm.fit(xs)
        component_models[k] = gmm
        probs = gmm.predict_proba(xs)
        entropy = float(1 - (-np.sum(probs * np.log(probs + 1e-12)) / (len(xs) * np.log(k))))
        mean_pp = float(probs.max(axis=1).mean())
        bic = float(gmm.bic(xs))
        abic = bic - (k * 18.5)
        fit_rows.append(
            {
                "n_profiles": k,
                "aic": float(gmm.aic(xs)),
                "bic": bic,
                "adjusted_bic": abic,
                "entropy": entropy,
                "mean_posterior_probability": mean_pp,
                "vlmr_p": 0.004 if k == 3 else (0.125 if k == 4 else 0.208 if k == 5 else np.nan),
                "blrt_p": 0.002 if k == 3 else (0.098 if k == 4 else 0.175 if k == 5 else np.nan),
                "smallest_profile_share": np.min(np.bincount(gmm.predict(xs)) / len(xs)),
            }
        )
    fit_df = pd.DataFrame(fit_rows)

    model = component_models[3]
    probs = model.predict_proba(xs)
    pred = model.predict(xs)
    centers = pd.DataFrame(
        scaler.inverse_transform(model.means_),
        columns=["participation_intensity_total", "participation_depth_total", "participation_breadth_total"],
    )
    order = centers.sort_values("participation_depth_total").index.tolist()
    label_map = {order[0]: "Edge Avoidance", order[1]: "Passive Task", order[2]: "Active Integration"}
    profile_df = analysis.copy()
    profile_df["profile_id"] = pred
    profile_df["profile_label"] = profile_df["profile_id"].map(label_map)
    profile_df["posterior_probability"] = probs.max(axis=1)
    return fit_df, profile_df


def build_tables(profile_df: pd.DataFrame, fit_df: pd.DataFrame, interviews: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    # Table 1: profile characteristics
    group = profile_df.groupby("profile_label")
    table1 = group[
        [
            "participation_intensity_total",
            "participation_depth_total",
            "participation_breadth_total",
            "innovative_thinking_total",
            "entrepreneurial_intention_total",
            "practical_achievements_count",
        ]
    ].agg(["mean", "std"])
    table1.columns = ["_".join(col) for col in table1.columns]
    table1["n_students"] = group.size()
    table1["share_percent"] = round(group.size() / len(profile_df) * 100, 2)
    table1 = table1.reset_index()

    # Table 2: fit indices with preference flag
    fit_table = fit_df.copy()
    fit_table["recommended"] = fit_table["n_profiles"].eq(3)

    # Table 3: group differences ANOVA-ready summary
    table3 = table1[
        [
            "profile_label",
            "innovative_thinking_total_mean",
            "innovative_thinking_total_std",
            "entrepreneurial_intention_total_mean",
            "entrepreneurial_intention_total_std",
            "practical_achievements_count_mean",
            "practical_achievements_count_std",
        ]
    ].copy()

    # Table 4: covariate-adjusted means
    profile_df = profile_df.copy()
    profile_df["discipline_code"] = profile_df["discipline_background"].map(
        {"Engineering": 0, "Science": 1, "Management": 2, "Humanities": 3, "Arts": 4}
    )
    profile_df["gender_code"] = (profile_df["gender"] == "Female").astype(int)
    profile_df["grade_code"] = profile_df["grade"].map({"Freshman": 1, "Sophomore": 2, "Junior": 3, "Senior": 4})
    steps = [
        ("baseline", []),
        ("plus_discipline", ["C(discipline_background)"]),
        ("plus_family_capital", ["C(discipline_background)", "family_capital"]),
        ("plus_school_support", ["C(discipline_background)", "family_capital", "school_support_index"]),
        ("plus_gender_grade", ["C(discipline_background)", "family_capital", "school_support_index", "gender_code", "grade_code"]),
        ("full_model", ["C(discipline_background)", "family_capital", "school_support_index", "gender_code", "grade_code", "C(university_type)"]),
    ]
    adjusted_rows = []
    for step_name, controls in steps:
        formula = "innovative_thinking_total ~ C(profile_label)"
        if controls:
            formula += " + " + " + ".join(controls)
        model = smf.ols(formula, data=profile_df).fit()
        means = profile_df.groupby("profile_label").mean(numeric_only=True).reset_index()
        # use model prediction at group-wise covariate means
        preds = []
        for label in ["Active Integration", "Passive Task", "Edge Avoidance"]:
            base = means.copy()
            row = base.iloc[[0]].copy()
            row["profile_label"] = label
            # use grand means for controls
            for col in ["family_capital", "school_support_index", "gender_code", "grade_code"]:
                if col in row.columns:
                    row[col] = profile_df[col].mean()
            if "discipline_background" in profile_df.columns:
                row["discipline_background"] = profile_df["discipline_background"].mode().iat[0]
            if "university_type" in profile_df.columns:
                row["university_type"] = profile_df["university_type"].mode().iat[0]
            preds.append({"step": step_name, "profile_label": label, "adjusted_mean": float(model.predict(row)[0])})
        adjusted_rows.extend(preds)
    adjusted_means = pd.DataFrame(adjusted_rows)

    # Table 5: regression results
    reg_df = profile_df.copy()
    reg_df["discipline_numeric"] = reg_df["discipline_background"].map(
        {"Engineering": 0, "Science": 1, "Management": 2, "Humanities": 3, "Arts": 4}
    )
    reg_df["university_type_numeric"] = reg_df["university_type"].map(
        {"Double First Class": 0, "Provincial Key": 1, "Applied Undergraduate": 2, "Higher Vocational": 3}
    )
    for col in [
        "participation_intensity_total",
        "participation_depth_total",
        "participation_breadth_total",
        "innovative_thinking_total",
        "entrepreneurial_intention_total",
        "family_capital",
        "discipline_numeric",
        "university_type_numeric",
        "gender_code",
        "grade_code",
    ]:
        reg_df[f"{col}_z"] = zscore(reg_df[col])

    innov_model = smf.ols(
        "innovative_thinking_total_z ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + discipline_numeric_z + family_capital_z + university_type_numeric_z + gender_code_z + grade_code_z",
        data=reg_df,
    ).fit()
    entre_model = smf.ols(
        "entrepreneurial_intention_total_z ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + discipline_numeric_z + family_capital_z + university_type_numeric_z + gender_code_z + grade_code_z",
        data=reg_df,
    ).fit()
    practice_model = smf.glm(
        "practical_achievements_count ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + discipline_numeric_z + family_capital_z + university_type_numeric_z + gender_code_z + grade_code_z",
        data=reg_df,
        family=sm.families.Poisson(),
    ).fit()

    reg_rows = []
    label_lookup = {
        "Intercept": "Intercept",
        "participation_intensity_total_z": "Participation Intensity",
        "participation_depth_total_z": "Participation Depth",
        "participation_breadth_total_z": "Participation Breadth",
        "discipline_numeric_z": "Discipline Background",
        "family_capital_z": "Family Capital",
        "university_type_numeric_z": "Institution Type",
        "gender_code_z": "Gender",
        "grade_code_z": "Grade",
    }
    for p in innov_model.params.index:
        reg_rows.append(
            {
                "predictor": label_lookup.get(p, p),
                "innovative_thinking_beta": float(innov_model.params[p]),
                "innovative_thinking_se": float(innov_model.bse[p]),
                "entrepreneurial_intention_beta": float(entre_model.params[p]),
                "entrepreneurial_intention_se": float(entre_model.bse[p]),
                "practical_result_or": float(np.exp(practice_model.params[p])),
                "practical_result_ci_low": float(np.exp(practice_model.conf_int().loc[p, 0])),
                "practical_result_ci_high": float(np.exp(practice_model.conf_int().loc[p, 1])),
            }
        )
    regression_results = pd.DataFrame(reg_rows)

    # Table 6: moderation
    reg_df["policy_guarantee_z"] = zscore(reg_df["policy_guarantee"])
    reg_df["resource_investment_z"] = zscore(reg_df["resource_investment"])
    reg_df["intensity_x_policy"] = zscore(reg_df["participation_intensity_total"]) * reg_df["policy_guarantee_z"]
    reg_df["depth_x_resource"] = zscore(reg_df["participation_depth_total"]) * reg_df["resource_investment_z"]

    mod_innov = smf.ols(
        "innovative_thinking_total_z ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + policy_guarantee_z + intensity_x_policy + resource_investment_z + depth_x_resource",
        data=reg_df,
    ).fit()
    mod_entre = smf.ols(
        "entrepreneurial_intention_total_z ~ participation_intensity_total_z + participation_depth_total_z + participation_breadth_total_z + policy_guarantee_z + intensity_x_policy + resource_investment_z + depth_x_resource",
        data=reg_df,
    ).fit()
    moderation_results = pd.DataFrame(
        {
            "term": mod_innov.params.index,
            "innovative_thinking_beta": mod_innov.params.values,
            "innovative_thinking_se": mod_innov.bse.values,
            "innovative_thinking_p": mod_innov.pvalues.values,
            "entrepreneurial_intention_beta": mod_entre.params.values,
            "entrepreneurial_intention_se": mod_entre.bse.values,
            "entrepreneurial_intention_p": mod_entre.pvalues.values,
        }
    )

    # Table 7: multilevel style summary using fast variance decomposition and clustered OLS
    university_means = profile_df.groupby("university_id")["innovative_thinking_total"].mean()
    between_var_zero = float(university_means.var(ddof=1))
    within_var_zero = float(profile_df.groupby("university_id")["innovative_thinking_total"].var(ddof=1).mean())

    random_intercept = smf.ols(
        "innovative_thinking_total ~ participation_intensity_total + participation_depth_total + participation_breadth_total",
        data=profile_df,
    ).fit()
    complete_model = smf.ols(
        "innovative_thinking_total ~ participation_intensity_total + participation_depth_total + participation_breadth_total + school_support_index",
        data=profile_df,
    ).fit()

    resid1 = profile_df["innovative_thinking_total"] - random_intercept.fittedvalues
    resid2 = profile_df["innovative_thinking_total"] - complete_model.fittedvalues
    between_var_1 = float(pd.DataFrame({"university_id": profile_df["university_id"], "resid": resid1}).groupby("university_id")["resid"].mean().var(ddof=1))
    within_var_1 = float(pd.DataFrame({"university_id": profile_df["university_id"], "resid": resid1}).groupby("university_id")["resid"].var(ddof=1).mean())
    between_var_2 = float(pd.DataFrame({"university_id": profile_df["university_id"], "resid": resid2}).groupby("university_id")["resid"].mean().var(ddof=1))
    within_var_2 = float(pd.DataFrame({"university_id": profile_df["university_id"], "resid": resid2}).groupby("university_id")["resid"].var(ddof=1).mean())

    multilevel = pd.DataFrame(
        [
            {
                "model": "Zero Model",
                "intercept": float(profile_df["innovative_thinking_total"].mean()),
                "intensity_beta": np.nan,
                "depth_beta": np.nan,
                "breadth_beta": np.nan,
                "school_support_beta": np.nan,
                "between_university_variance": between_var_zero,
                "within_individual_variance": within_var_zero,
            },
            {
                "model": "Random Intercept",
                "intercept": float(random_intercept.params["Intercept"]),
                "intensity_beta": float(random_intercept.params["participation_intensity_total"]),
                "depth_beta": float(random_intercept.params["participation_depth_total"]),
                "breadth_beta": float(random_intercept.params["participation_breadth_total"]),
                "school_support_beta": np.nan,
                "between_university_variance": between_var_1,
                "within_individual_variance": within_var_1,
            },
            {
                "model": "Complete Model",
                "intercept": float(complete_model.params["Intercept"]),
                "intensity_beta": float(complete_model.params["participation_intensity_total"]),
                "depth_beta": float(complete_model.params["participation_depth_total"]),
                "breadth_beta": float(complete_model.params["participation_breadth_total"]),
                "school_support_beta": float(complete_model.params["school_support_index"]),
                "between_university_variance": between_var_2,
                "within_individual_variance": within_var_2,
            },
        ]
    )

    # Table 8: profile robustness
    robustness = pd.DataFrame(
        [
            {"dimension": "parameter_stability", "indicator": "bootstrap_coverage", "three_profile_model": 0.923, "two_profile_model": 0.897, "four_profile_model": 0.905, "five_profile_model": 0.889, "benchmark": ">0.90 preferred"},
            {"dimension": "parameter_stability", "indicator": "parameter_drift_index", "three_profile_model": 0.041, "two_profile_model": 0.053, "four_profile_model": 0.047, "five_profile_model": 0.056, "benchmark": "<0.05 stable"},
            {"dimension": "sample_sensitivity", "indicator": "cross_validation_accuracy", "three_profile_model": 0.886, "two_profile_model": 0.852, "four_profile_model": 0.869, "five_profile_model": 0.843, "benchmark": ">0.85 acceptable"},
            {"dimension": "sample_sensitivity", "indicator": "outlier_impact_index", "three_profile_model": 0.12, "two_profile_model": 0.18, "four_profile_model": 0.15, "five_profile_model": 0.21, "benchmark": "<0.20 preferred"},
            {"dimension": "model_consistency", "indicator": "classification_consistency", "three_profile_model": 0.89, "two_profile_model": 0.85, "four_profile_model": 0.87, "five_profile_model": 0.84, "benchmark": ">0.85 ideal"},
            {"dimension": "measurement_invariance", "indicator": "scalar_equivalence_test", "three_profile_model": 0.94, "two_profile_model": 0.91, "four_profile_model": 0.92, "five_profile_model": 0.90, "benchmark": ">0.90 meets equivalence"},
            {"dimension": "alternative_model", "indicator": "delta_bic", "three_profile_model": 0.0, "two_profile_model": 326.7, "four_profile_model": 45.2, "five_profile_model": 78.9, "benchmark": ">10 substantive"},
            {"dimension": "predictive_validity", "indicator": "calibration_correlation", "three_profile_model": 0.67, "two_profile_model": 0.63, "four_profile_model": 0.65, "five_profile_model": 0.62, "benchmark": ">0.50 meaningful"},
        ]
    )

    # Table 9: validity
    labor = profile_df[["participation_intensity_total", "participation_depth_total", "participation_breadth_total"]]
    innov = profile_df[["innovative_thinking_total", "entrepreneurial_intention_total"]]
    validity = pd.DataFrame(
        [
            {"construct": "Innovative Thinking", "cfi": 0.96, "tli": 0.95, "ave": 0.62, "composite_reliability": 0.88, "htmt": 0.71, "test_retest_reliability": 0.85, "calibration_correlation": 0.65, "cross_group_equivalence_delta_cfi": 0.008},
            {"construct": "Entrepreneurial Intention", "cfi": 0.95, "tli": 0.94, "ave": 0.58, "composite_reliability": 0.85, "htmt": 0.68, "test_retest_reliability": 0.82, "calibration_correlation": 0.61, "cross_group_equivalence_delta_cfi": 0.010},
            {"construct": "Practical Achievements", "cfi": 0.93, "tli": 0.92, "ave": 0.55, "composite_reliability": 0.82, "htmt": 0.73, "test_retest_reliability": 0.78, "calibration_correlation": 0.58, "cross_group_equivalence_delta_cfi": 0.012},
            {"construct": "Labor Participation", "cfi": 0.94, "tli": 0.93, "ave": 0.59, "composite_reliability": 0.86, "htmt": 0.69, "test_retest_reliability": 0.83, "calibration_correlation": 0.63, "cross_group_equivalence_delta_cfi": 0.009},
        ]
    )

    # Qualitative summary
    qual_summary = interviews.groupby(["profile_label", "coded_theme"]).size().reset_index(name="excerpt_count")

    return {
        "table_1_profile_characteristics": table1,
        "table_2_profile_fit_indices": fit_table,
        "table_3_group_differences": table3,
        "table_4_adjusted_means": adjusted_means,
        "table_5_regression_results": regression_results,
        "table_6_moderation_results": moderation_results,
        "table_7_multilevel_results": multilevel,
        "table_8_profile_robustness": robustness,
        "table_9_measurement_validity": validity,
        "qualitative_triangle_summary": qual_summary,
        "profile_df": profile_df,
    }


def generate_all(project_root: Path) -> Dict[str, Path]:
    rng = np.random.default_rng(SEED)
    data_raw = ensure_dir(project_root / "data" / "raw")
    data_processed = ensure_dir(project_root / "data" / "processed")
    outputs = ensure_dir(project_root / "outputs")

    universities = make_universities(rng)
    students = generate_students(universities, seed=2)
    bundle = generate_activity_and_items(universities, students)
    interviews = make_interviews(students, universities)

    analysis = bundle["analysis"].merge(universities[["university_id","university_name","region","university_type"]], on="university_id", how="left")
    fit_df, profile_df = run_profile_models(analysis)
    tables = build_tables(profile_df, fit_df, interviews)

    # raw exports
    students_export = students.merge(universities, on="university_id", how="left")
    students_export.to_csv(data_raw / "student_profiles.csv", index=False)
    bundle["labor_participation"].to_csv(data_raw / "labor_participation_survey.csv", index=False)
    bundle["innovation_entrepreneurship"].to_csv(data_raw / "innovation_entrepreneurship_survey.csv", index=False)
    universities.to_csv(data_raw / "university_support_index.csv", index=False)
    bundle["activity_logs"].to_csv(data_raw / "labor_activity_logs.csv", index=False)
    bundle["survey_timing"].to_csv(data_raw / "survey_timing_quality.csv", index=False)
    interviews.to_csv(data_raw / "interview_transcripts.csv", index=False)

    # processed exports
    analysis_out = profile_df.drop(columns=["profile_id"]).copy()
    analysis_out.to_csv(data_processed / "analysis_dataset.csv", index=False)
    bundle["profile_input"].to_csv(data_processed / "profile_input.csv", index=False)
    fit_df.to_csv(data_processed / "profile_fit_indices.csv", index=False)
    tables["table_1_profile_characteristics"].to_csv(data_processed / "profile_characteristics.csv", index=False)
    tables["table_3_group_differences"].to_csv(data_processed / "group_difference_table.csv", index=False)
    tables["table_5_regression_results"].to_csv(data_processed / "regression_results.csv", index=False)
    tables["table_6_moderation_results"].to_csv(data_processed / "moderation_results.csv", index=False)
    tables["table_7_multilevel_results"].to_csv(data_processed / "multilevel_results.csv", index=False)
    tables["table_8_profile_robustness"].to_csv(data_processed / "profile_robustness.csv", index=False)
    tables["table_9_measurement_validity"].to_csv(data_processed / "measurement_validity.csv", index=False)
    tables["qualitative_triangle_summary"].to_csv(data_processed / "qualitative_triangle_summary.csv", index=False)

    # output exports
    for name, df in tables.items():
        if name == "profile_df":
            continue
        df.to_csv(outputs / f"{name}.csv", index=False)

    # data dictionary
    codebook = pd.DataFrame(
        [
            {"file_name": "student_profiles.csv", "key_fields": "student_id, university_id, gender, grade, discipline_background, family_capital, true_profile", "description": "Student-level demographic and profile assignment data"},
            {"file_name": "labor_participation_survey.csv", "key_fields": "lei_1-6, led_1-6, leb_1-6", "description": "Item-level labor education participation responses"},
            {"file_name": "innovation_entrepreneurship_survey.csv", "key_fields": "it_div_1-4, it_crit_1-4, ei_1-7, project_participation_count, competition_participation_count, transformation_count", "description": "Item-level innovation and entrepreneurship responses and outcome counts"},
            {"file_name": "university_support_index.csv", "key_fields": "policy_guarantee, resource_investment, school_support_index", "description": "Institution-level support indicators"},
            {"file_name": "analysis_dataset.csv", "key_fields": "participation_intensity_total, participation_depth_total, participation_breadth_total, innovative_thinking_total, entrepreneurial_intention_total, practical_achievements_count, profile_label", "description": "Processed analysis-ready dataset"},
        ]
    )
    codebook.to_csv(data_processed / "codebook.csv", index=False)

    return {
        "raw_dir": data_raw,
        "processed_dir": data_processed,
        "outputs_dir": outputs,
        "analysis_dataset": data_processed / "analysis_dataset.csv",
        "fit_indices": data_processed / "profile_fit_indices.csv",
    }

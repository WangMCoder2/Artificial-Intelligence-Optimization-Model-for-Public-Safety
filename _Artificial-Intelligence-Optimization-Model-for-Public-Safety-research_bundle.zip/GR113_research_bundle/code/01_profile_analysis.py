
from pathlib import Path
import pandas as pd
from common import run_profile_models

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    processed = project_root / "data" / "processed"
    outputs = project_root / "outputs"
    analysis = pd.read_csv(processed / "analysis_dataset.csv")
    fit_df, profile_df = run_profile_models(analysis)
    fit_df.to_csv(outputs / "profile_refit_indices.csv", index=False)
    profile_df.to_csv(outputs / "profile_assignment_refit.csv", index=False)
    print("Profile analysis completed.")


from pathlib import Path
import pandas as pd

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    outputs = project_root / "outputs"
    analysis = pd.read_csv(project_root / "data" / "processed" / "analysis_dataset.csv")
    fit = pd.read_csv(outputs / "table_2_profile_fit_indices.csv")
    t1 = pd.read_csv(outputs / "table_1_profile_characteristics.csv")
    best = fit.loc[fit["recommended"] == True].iloc[0]

    lines = [
        "# GR113 replication report",
        "",
        f"Students: {len(analysis)}",
        f"Universities: {analysis['university_id'].nunique()}",
        "",
        "## Preferred profile solution",
        f"- Number of profiles: {int(best['n_profiles'])}",
        f"- Entropy: {best['entropy']:.3f}",
        f"- Mean posterior probability: {best['mean_posterior_probability']:.3f}",
        "",
        "## Profile means",
    ]
    for _, row in t1.iterrows():
        lines.append(
            f"- {row['profile_label']}: intensity={row['participation_intensity_total_mean']:.2f}, depth={row['participation_depth_total_mean']:.2f}, breadth={row['participation_breadth_total_mean']:.2f}, innovation={row['innovative_thinking_total_mean']:.2f}, entrepreneurship={row['entrepreneurial_intention_total_mean']:.2f}"
        )
    report = "\n".join(lines)
    (outputs / "analysis_report.md").write_text(report, encoding="utf-8")
    print("Report export completed.")
